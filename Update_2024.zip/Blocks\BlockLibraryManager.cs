﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using Autodesk.AutoCAD.ApplicationServices;

namespace TTFL.PCCC
{
    public static class BlockLibraryManager
    {
        private static Dictionary<string, string> _blockCache = new Dictionary<string, string>();
        public static bool IsLoaded { get; private set; } = false;

        public static void LoadAllBlocks(string rootFolder)
        {
            var ed = Application.DocumentManager.MdiActiveDocument.Editor;
            ed.WriteMessage($"\n\n=== HỆ THỐNG NẠP THƯ VIỆN BLOCK ===");
            ed.WriteMessage($"\n[Đang quét] Thư mục: {rootFolder}");

            // 1. KIỂM TRA THƯ MỤC CÓ TỒN TẠI KHÔNG (Báo cáo rõ ràng)
            if (!Directory.Exists(rootFolder))
            {
                ed.WriteMessage($"\n[LỖI CHÍ MẠNG] KHÔNG TÌM THẤY THƯ MỤC BLOCKS TẠI ĐƯỜNG DẪN TRÊN!");
                ed.WriteMessage($"\n=> Hướng xử lý: Hãy copy thư mục Blocks của bạn và dán chính xác vào đường dẫn đó.");
                ed.WriteMessage($"\n=====================================\n");
                return;
            }

            _blockCache.Clear();
            string[] subDirs = Directory.GetDirectories(rootFolder);

            // 2. REGEX MỚI NHẤT (Chỉ bắt các số ở cuối tên file, phớt lờ số 90 và 45)
            Regex sizeRegex = new Regex(@"(?:DN)?\s*(\d+)(?:x(\d+))?\s*$", RegexOptions.IgnoreCase);

            foreach (string dir in subDirs)
            {
                string folderName = Path.GetFileName(dir).ToLower();
                string[] files = Directory.GetFiles(dir, "*.dwg");

                foreach (string file in files)
                {
                    string fileName = Path.GetFileNameWithoutExtension(file);
                    Match match = sizeRegex.Match(fileName);

                    if (match.Success)
                    {
                        string size1 = match.Groups[1].Value;
                        string size2 = match.Groups[2].Success ? match.Groups[2].Value : "0";
                        string key = $"{folderName}_{size1}_{size2}";

                        if (!_blockCache.ContainsKey(key))
                        {
                            _blockCache.Add(key, file);
                        }
                    }
                }
            }
            IsLoaded = true;
            ed.WriteMessage($"\n[THÀNH CÔNG] Đã nạp {_blockCache.Count} phụ kiện vào bộ nhớ đệm Cache O(1).");
            ed.WriteMessage($"\n=====================================\n");
        }

        public static string GetFittingPath(string fittingType, string connType, double mainDN, double branchDN = 0)
        {
            string targetFolder = $"{fittingType.ToLower()} {connType.ToLower()}";
            string searchKey = $"{targetFolder}_{mainDN}_{branchDN}";

            if (_blockCache.TryGetValue(searchKey, out string filePath))
            {
                return filePath;
            }

            if (branchDN > 0)
            {
                string reverseSearchKey = $"{targetFolder}_{branchDN}_{mainDN}";
                if (_blockCache.TryGetValue(reverseSearchKey, out string reverseFilePath))
                {
                    return reverseFilePath;
                }
            }

            return null;
        }
    }
}